﻿namespace GrouosAPI.Models.DTO
{
    public class addReportDto
    {
        public string ReportReason { get; set; }
        public string? ReportDesc { get; set; }
    }
}
