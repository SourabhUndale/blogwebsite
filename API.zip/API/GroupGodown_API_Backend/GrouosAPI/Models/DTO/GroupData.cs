﻿namespace GrouosAPI.Models.DTO
{
    public class GroupData
    {
        public string GroupName { get; set; }
        public string ImageLink { get; set; }
    }
}
