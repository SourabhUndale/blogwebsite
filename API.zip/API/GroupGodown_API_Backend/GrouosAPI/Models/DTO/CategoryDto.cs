﻿namespace GrouosAPI.Models.DTO
{
    public class CategoryDto
    {
        public int id { get; set; }

        public string name { get; set; }
    }
}
