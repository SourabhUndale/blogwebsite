﻿namespace GrouosAPI.Models.DTO
{
    public class ReportDto
    {
        public int ReportId { get; set; }
        public string ReportReason { get; set; }
        public string ReportDesc { get; set; }     
    }
}
