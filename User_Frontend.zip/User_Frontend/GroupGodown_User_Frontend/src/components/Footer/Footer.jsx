import React from "react";

function Footer() {
  return (
    <>
      <div>
        <hr />
        <p className="pe-3 text-center">All Right Reserved - 2024 GroupGodown</p>
      </div>
    </>
  );
}

export default Footer;
