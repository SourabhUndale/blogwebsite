import { useState } from "react";
import "./App.css";
import SideBar from "./components/Navbar/SideBar";

function App() {
  return (
    <>
      <div>
        <SideBar />
      </div>
    </>
  );
}

export default App;
